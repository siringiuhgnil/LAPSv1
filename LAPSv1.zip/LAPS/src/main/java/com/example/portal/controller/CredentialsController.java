package com.example.portal.controller;

public class CredentialsController {

}
