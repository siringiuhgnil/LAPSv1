package com.example.portal.model;

public class Holidaylist {

}
